export { SignUp as default } from "@clerk/nextjs";
